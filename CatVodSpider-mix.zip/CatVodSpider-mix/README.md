# CatVodSpider

### Based on CatVod

https://github.com/CatVodTVOfficial/CatVodTVSpider

### Usage

[fastgit](https://raw.fastgit.org/FongMi/CatVodSpider/main/json/config.json)  
[gh-proxy](https://gh-proxy.com/https://raw.githubusercontent.com/FongMi/CatVodSpider/main/json/config.json)  
[https://fongmi.page.link/cat](https://fongmi.page.link/cat)  
